﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EnrollmentSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            load();
        }

        private void load()
        {

            try
            {
                fn.connDB();
                fn.da = new SqlDataAdapter(fn.sql = "SELECT * FROM tbl_student", fn.conn);
                fn.dt = new DataTable();
                fn.da.Fill(fn.dt);
                dataGridView1.DataSource = fn.dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            try {
                fn.sql = "INSERT INTO tbl_student(std_id, std_name, std_mname, std_lname) VALUES ('"+this.textBox1.Text+"', '"+this.textBox2.Text+"', '"+this.textBox3.Text+"', '"+this.textBox4.Text+"')";
                fn.connDB();
                fn.cmd = new SqlCommand(fn.sql, fn.conn);
                fn.dr = fn.cmd.ExecuteReader();
                load();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                MessageBox.Show("Successfully saved.");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            DataGridView dgv = sender as DataGridView;
            if(dgv != null && dgv.SelectedRows.Count > 0)
            {
                DataGridViewRow row1 = dgv.SelectedRows[0];
                if (row1 != null)
                {
                    textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                    textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                    textBox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                    textBox4.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                    
                }
            }
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                fn.sql = "UPDATE tbl_student SET std_id = '" + textBox1.Text+"'.'"+ this.textBox2.Text + "','" + this.textBox3.Text +"' ,std_lname ='" +this.textBox4.Text +"' WHERE std_id'" +textBox1.Text'")";
                    fn.connDB();
                fn.cmd = new SqlCommand(fn.sql ,fn.conn);
                fn.cmd.ExecuteNonQuery();
                load();
                 textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                MessageBox.Show("Successfully saved.");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

           

            }
        }
    }
}
