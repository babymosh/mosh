﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    class fn
    {
        public static string sql;
        public static SqlCommand cmd = new SqlCommand();
        public static SqlDataReader dr;
        public static SqlDataAdapter da = new SqlDataAdapter();
        public static DataTable dt = new DataTable();
        public static SqlConnection conn = new SqlConnection();


        public static void connDB()
        {
            conn.Close();
            try
            {

                conn.ConnectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=c:\users\user\documents\visual studio 2013\Projects\WindowsFormsApplication3\WindowsFormsApplication3\Database1.mdf;Integrated Security=True";
                conn.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}